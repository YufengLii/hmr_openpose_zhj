const fs = require('fs');
const path = require('path');
const RedisSMQ = require("rsmq");

var exec = require('child_process').exec;

var express = require('express');
var router = express.Router();

const FACE_IMG_QUEUE = "faceImg";


const FACE_MJPEG = path.join(__dirname, '../public/resource/face.jpg');
const SMPL_ORIG  = path.join(__dirname, '../public/resource/original.jpg');
const SMPL_RENDER = path.join(__dirname, '../public/resource/rendered.jpg');

// const FACE_MJPEG = __dirname + "/../" + 'public/resource/face.jpg';
// const SMPL_ORIG = __dirname + "/../" + "public/resource/original.jpg";
// const SMPL_RENDER = __dirname + "/../" + "public/resource/rendered.jpg";

const now = function(){ return Math.floor( new Date().getTime()/1000 );};

rsmq = new RedisSMQ( {host: "127.0.0.1", port: 6379, ns: "rsmq"} );


/*
const rsmq = new RedisSMQ( {host: '127.0.0.1', port: 6379, ns: "rsmq"} );

var face_img;
const queryFaceImg = function() {
    return rsmq.receiveMessageAsync({qname: FACE_IMG_QUEUE})
        .then(function (resp) {
            if (resp.id) {
                face_img = resp.message;
            }
            else {
                console.log("[RSMQ] FACE - No messages for me...")
            }

            /// Delete after consume
            rsmq.deleteMessage({qname:FACE_IMG_QUEUE, id: resp.id}, function (err, resp) {
                if (resp===1) {
                    // console.log("[RSMQ] VIBRATION Message deleted.")
                }
                else {
                    logger.error("[RSMQ] VIBRATION Message not found.", resp.id)
                }
            });
    })
        .catch(function (err) {

            console.error(`[RSMQ] FACEIMG - [ERROR] RECEIVE queue ${QCAL} failed:, ${err.message}`)
        });
};

setInterval(queryFaceImg, 50);
*/

/* GET home page. */
router.get('/', function(req, res, next) {
  res.sendfile('public/viewply.html');
  // res.sendfile('public/webgl_loader_ply.html')
});

router.get('/3d', function(req, res, next) {
  res.sendfile('public/css3d_panorama.html');
});

router.get('/smpl', function(req, res, next) {
  res.sendfile('public/smpl2.html');
});



router.get('/2_0.ply', function (req, res, netxt) {
  //res.sendfile('public/resource/2_0.ply');
  const PLYFILE = '/home/helab/Documents/ramdisk/2_0.ply';
  res.sendfile('/home/helab/Documents/ramdisk/2_0.ply');

  // binding.files([PLYFILE], function (err, result) {
  //     if (err) {
  //         console.log(err)
  //         res.end();
  //         return;
  //     }
  //     try {
  //         if (PLYFILE in result && result[PLYFILE] === false) {
  //             res.sendfile(PLYFILE);
  //         } else if (path.basename(PLYFILE) in result && result[path.basename(PLYFILE)] === false) {
  //             res.sendfile(PLYFILE);
  //         } else {
  //             console.log(result)
  //             res.end()
  //         }
  //     } catch (e) {
  //         console.log("[BINDING] 2_0.ply", e)
  //     }

  // })


});

router.get('/api/face.json', function (req, res, netxt) {
  const IMG = __dirname + '/../public/resource/face.json';



  fs.open(__dirname + '/../public/resource/face.json', 'r+', function(err, fd) {
    if (err) {
      console.log("[ERROR] face.json", err.message)
      res.end();
    } else {
      res.sendfile('public/resource/face.json');
    }
    fs.close(fd, function(){})
  })

//  binding.files([IMG], function (err, result) {
//         if (err) {
//             console.log(err)
//             res.end();
//             return;
//         }
//         try {
//             if (IMG in result && result[IMG] === false) {
//                 res.sendfile(IMG);
//             } else if (path.basename(IMG) in result && result[path.basename(IMG)] === false) {
//                 res.sendfile(IMG);
//             } else {
//                 console.log(result)
//                 res.end()
//             }
//         } catch (e) {
//             console.log("[BINDING] face.json", e)
//         }

//   })



});



router.get('/face1111.mjpg', function (req, res, netxt) {
  const IMG = FACE_MJPEG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;
  var mtime = 0;
  const updateImgInterval = setInterval(function () {
    if (stop) clearInterval(updateImgInterval)


    rsmq.receiveMessageAsync({qname: FACE_IMG_QUEUE})
        .then(function (resp) {
          // console.log(resp)
          if (resp.id) {

            rsmq.deleteMessage({qname:FACE_IMG_QUEUE, id: resp.id}, function (err, resp) {
              if (resp===1) {
                // console.log("[RSMQ] VIBRATION Message deleted.")
              }
              else {
                console.error("[RSMQ] VIBRATION Message not found.", resp.id)
              }
            });


            send_next(Buffer.from(resp.message, 'base64'))
          }
          else {
            console.log("[RSMQ] FACE - No messages for me...")
          }


        })
        .catch(function (err) {
          console.error(`[RSMQ] FACEIMG - [ERROR] RECEIVE queue ${FACE_IMG_QUEUE} failed:, ${err.message}`)
        });


  }, 100);

  res.connection.on('close', function() { stop = true; });

  const send_next = function(data) {

    if (stop) return;

    // fs.readFile(IMG, function (err, content) {
    res.write("--myboundary\r\n");
    res.write("Content-Type: image/jpeg\r\n");
    res.write("Content-Length: " + data.length + "\r\n");
    res.write("\r\n");
    res.write(data, 'binary');
    res.write("\r\n");

    // });
  };
  // send_next();

});


router.get('/face.mjpg', function (req, res, netxt) {
  const IMG = FACE_MJPEG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;
  var mtime = 0;
  const updateImgInterval = setInterval(function () {

    var st = fs.statSync(IMG);
    if (st && 'mtimeMs' in st && st.mtimeMs - mtime > 0) {
      send_next()
      mtime = st.mtimeMs;
    }

  }, 100);

  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});

router.get('/face.mjpg1', function (req, res, netxt) {
  const IMG = FACE_MJPEG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {

      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }
  });

  var i = 0;
  const update = setInterval(function () {
    i = (i+1);
    if (stop) {
      clearInterval(update);
      watcher.close();
      res.end();
    }
    var ii = (i) % 100;
    // var filename =  __dirname + '/../public/resource/img/' +  ii + ".jpg";
    var filename = __dirname + '/../public/resource/selfie3f.jpg';


    var txt = fs.readFileSync ( filename,  'binary');

    fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})
    /*
    cmd = "cp -rf " + filename + " " + IMG;
    exec(cmd, function(err, stdout, stderr) {
      if (err) {
        console.log(err)
      }
    });*/

  }, 1000);

  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


router.get('/smpl_orig.mjpg', function (req, res, netxt) {

  const IMG = SMPL_ORIG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {
      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }

  });


  var i = 0;
  const update = setInterval(function () {
    i = (i+1);
    if (i > 100 || stop) {
      clearInterval(update);
      watcher.close();
      res.end();
    }
    var ii = (i) % 100;
    var filename =  __dirname + '/../public/resource/original11.jpg';

    var txt = fs.readFileSync ( filename,  'binary');

    fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})


  }, 1000);


  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


router.get('/smpl_render.mjpg', function (req, res, netxt) {

  const IMG = SMPL_RENDER;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {
      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }

  });

  /*
    var i = 0;
    const update = setInterval(function () {
      i = (i+1);
      if (i > 100 || stop) {
        clearInterval(update);
        watcher.close();
        res.end();
      }
      var ii = (i) % 100;
      var filename =  __dirname + '/../public/resource/img/' +  ii + ".jpg";
      console.log(1111, filename);

      var txt = fs.readFileSync ( filename,  'binary');

      fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})


    }, 200);
    */

  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


module.exports = router;
