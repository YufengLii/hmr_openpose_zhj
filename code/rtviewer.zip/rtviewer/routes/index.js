const fs = require('fs');
const path = require('path');
const RedisSMQ = require("rsmq");

var exec = require('child_process').exec;

var express = require('express');
var router = express.Router();

const FACE_IMG_QUEUE = "faceImgQue";
const FACE_PLY_QUEUE = "facePlyQue";
const SMPL_ORIG_QUEUE = "smplOrigQue";
const SMPL_OBJ_QUEUE = "smplObjQue";


const FACE_PLY_WF = path.join(__dirname, '../public/resource/1_0.ply');
const FACE_MJPEG = path.join(__dirname, '../public/resource/face.jpg');
const SMPL_ORIG = path.join(__dirname, '../public/resource/original.jpg');
// const SMPL_RENDER = path.join(__dirname, '../public/resource/rendered.jpg');
const SMPL_OBJ = path.join(__dirname, '../public/resource/model/result.obj');


const FACE_TIMEOUT = 2*60;  // 2min





const now = function () {
    return Math.floor(new Date().getTime() / 1000);
};

rsmq = new RedisSMQ({host: "127.0.0.1", port: 6379, ns: "rsmq"});


/* GET home page. */
router.get('/face', function (req, res, next) {
    //res.sendfile('public/viewply.html');
    // res.sendfile('public/webgl_loader_ply.html')
});

router.get('/3d', function (req, res, next) {
    res.sendfile('public/css3d_panorama.html');
});

router.get('/', function (req, res, next) {
    res.sendfile('public/smpl2.html');
});


router.get('/1_0.ply', function (req, res, netxt) {
    res.sendfile(FACE_PLY_WF);
});

/*
router.get('/2_0.ply', function (req, res, netxt) {
  //res.sendfile('public/resource/2_0.ply');
  const PLYFILE = '/home/helab/Documents/ramdisk/2_0.ply';
  res.sendfile('/home/helab/Documents/ramdisk/2_0.ply');

});*/

const SMPL_STATIC_JPEG = path.join(__dirname, '../public/resource/original11.jpg');
const SMPL_STATIC_OBJ = path.join(__dirname, '../public/resource/model/result.obj');
const SMPL_STATIC_JSON = path.join(__dirname, '../public/resource/model/human1.json');
var smplTO = {
    flag: false,
    smplTimeoutCB: null,
    prevMsg: null,
    obj: SMPL_STATIC_OBJ,
    img: SMPL_STATIC_JPEG,
    json: SMPL_STATIC_JSON,
    timeout: 10
};



var faceTO = false;
var faceTimeoutCB = null;
var plymsgs = [];
var ply = fs.readFileSync(FACE_PLY_WF);
var prevMsg = null;

router.get('/2_0.ply', function (req, res, netxt) {
    const QUEUE = FACE_PLY_QUEUE;

    rsmq.receiveMessageAsync({qname: QUEUE, vt: 0})
        .then(function (resp) {
            // console.log(resp)
            if (resp.id) {
                // console.log('ply', resp.id, prevMsg, plymsgs);
                if (faceTimeoutCB && resp.id !== prevMsg ) {
                    try {
                        faceTO = false;
                        clearTimeout(faceTimeoutCB);
                        faceTimeoutCB = null;
                    } catch (e) {
                        console.log("[FACE] Cancel TO CB ERROR", e);
                    }
                }

                prevMsg = resp.id;

                ply = Buffer.from(resp.message, 'base64');

                if (faceTimeoutCB === null) {
                    faceTimeoutCB = setTimeout(function () {
                        faceTO = true;
                        console.log("\n\n!!!!TO!!!\n\n");
                    }, 1000*FACE_TIMEOUT); // 2 min
                }

            } else {
                console.log("[RSMQ] PLY - No messages for me...")
            }

            if (faceTO) {
                res.sendfile(FACE_PLY_WF);
            } else {
                res.end(ply, 'binary');
            }

        })
        .catch(function (err) {
            console.error(`[RSMQ] FACEIMG - [ERROR] RECEIVE queue ${FACE_IMG_QUEUE} failed:, ${err.message}`)
        });

});


router.get('/api/face.json', function (req, res, netxt) {
    res.sendfile('public/resource/face.json');
});




router.get('/face.mjpg', function (req, res, netxt) {
    const IMG = FACE_MJPEG;
    const QUE = FACE_IMG_QUEUE;
    res.writeHead(200, {
        'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
        'Cache-Control': 'no-cache',
        'Connection': 'close',
        'Pragma': 'no-cache'
    });

    var stop = false;

    const send_next = function (data) {
        if (stop) return;

        res.write("--myboundary\r\n");
        res.write("Content-Type: image/jpeg\r\n");
        res.write("Content-Length: " + data.length + "\r\n");
        res.write("\r\n");
        res.write(data, 'binary');
        res.write("\r\n");
    };

    send_next(fs.readFileSync(IMG));

    const updateImgInterval = setInterval(function () {
        if (stop) clearInterval(updateImgInterval);

        if (faceTO) {
            send_next(fs.readFileSync(IMG))
        } else {
            rsmq.receiveMessageAsync({qname: QUE, vt: 0})
                .then(function (resp) {
                    if (resp.id) {
                        send_next(Buffer.from(resp.message, 'base64'))

                    } else {
                        console.log("[RSMQ] FACE - No messages for me...")
                    }
                })
                .catch(function (err) {
                    console.error(`[RSMQ] FACEIMG - [ERROR] RECEIVE queue ${QUE} failed:, ${err.message}`)
                });
        }

    }, 100);

    res.connection.on('close', function () {
        stop = true;
    });
});


router.get('/smpl_orig.mjpg', function (req, res, netxt) {
    const IMG = SMPL_ORIG;
    const QUE = SMPL_ORIG_QUEUE;

    res.writeHead(200, {
        'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
        'Cache-Control': 'no-cache',
        'Connection': 'close',
        'Pragma': 'no-cache'
    });

    var stop = false;

    const send_next = function (data) {
        if (stop) return;

        res.write("--myboundary\r\n");
        res.write("Content-Type: image/jpeg\r\n");
        res.write("Content-Length: " + data.length + "\r\n");
        res.write("\r\n");
        res.write(data, 'binary');
        res.write("\r\n");
    };

    send_next(fs.readFileSync(IMG));

    const updateImgInterval = setInterval(function () {
        if (stop) clearInterval(updateImgInterval);

        if (smplTO.flag) {
            send_next(fs.readFileSync(smplTO.img))
        } else {
            rsmq.receiveMessageAsync({qname: QUE, vt: 0})
                .then(function (resp) {
                    if (resp.id) {

                        send_next(Buffer.from(resp.message, 'base64'))
                        console.log("rev img", resp.id)
                    } else {
                        console.log("[RSMQ] SMPL ORIG - No messages for me...")
                    }
                })
                .catch(function (err) {
                    console.error(`[RSMQ] SMPL ORIG - [ERROR] RECEIVE queue ${QUE} failed:, ${err.message}`)
                });
        }

    }, 100);

    res.connection.on('close', function () {
        stop = true;
    });
});



var obj = fs.readFileSync(SMPL_OBJ);
router.get('/result.obj', function (req, res, netxt) {
    const QUEUE = SMPL_OBJ_QUEUE;
    rsmq.receiveMessageAsync({qname: QUEUE, vt: 0})
        .then(function (resp) {
            console.log(resp.id, resp.message.slice(0, 5))
            if (resp.id) {


                if (smplTO.smplTimeoutCB && resp.id !== smplTO.prevMsg) {
                    try {
                        smplTO.flag = false;
                        clearTimeout(smplTO.smplTimeoutCB);
                        smplTO.smplTimeoutCB = null;
                    } catch (e) {
                        console.log("[SMPL] Cancel TO CB ERROR", e)
                    }
                }

                smplTO.prevMsg = resp.id;
                obj = resp.message;

                if (smplTO.smplTimeoutCB === null) {
                    smplTO.smplTimeoutCB = setTimeout(function () {
                        smplTO.flag = true;
                        console.log("\n\n!!!!TO!!!\n\n");
                    }, 1000*smplTO.timeout)
                }


            } else {
                console.log("[RSMQ] OBJ - No messages for me...")
            }

            if (smplTO.flag) {
                res.sendfile(smplTO.obj);
            } else {
                res.send(obj);
            }

        })
        .catch(function (err) {
            console.error(`[RSMQ] OBJ - [ERROR] RECEIVE queue ${FACE_IMG_QUEUE} failed:, ${err.message}`)
        });
});



router.get('/api/human.json', function (req, res, next) {

    if (smplTO.flag) {
        res.sendfile(smplTO.json);
    } else {
        res.sendfile('public/resource/model/human.json');
    }
});


/*
var obj = fs.readFileSync(SMPL_OBJ);
router.get('/result.obj', function (req, res, netxt) {
    const QUEUE = SMPL_OBJ_QUEUE;
    rsmq.receiveMessageAsync({qname: QUEUE, vt: 0})
        .then(function (resp) {
            //console.log(resp.id, resp.message.slice(0, 50))
            if (resp.id) {
                // obj = Buffer.from(resp.message, 'base64');
                obj = resp.message;
                //fs.writeFileSync('aa.obj', obj);
            } else {
                console.log("[RSMQ] OBJ - No messages for me...")
            }

            // res.end(ply, 'binary');
            res.send(obj)

        })
        .catch(function (err) {
            console.error(`[RSMQ] OBJ - [ERROR] RECEIVE queue ${FACE_IMG_QUEUE} failed:, ${err.message}`)
        });
});*/



router.get('/result1111.obj', function (req, res, netxt) {
  //res.sendfile('public/resource/2_0.ply');
  res.sendfile('public/resource/model/result.obj');

});

/*
router.get('/result1111.obj', function (req, res, netxt) {
    const IMG = SMPL_ORIG;
    const QUE = SMPL_OBJ_QUEUE;

    res.writeHead(200, {
        'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
        'Cache-Control': 'no-cache',
        'Connection': 'close',
        'Pragma': 'no-cache'
    });

    var stop = false;

    const send_next = function (data) {
        if (stop) return;

        res.write("--myboundary\r\n");
        res.write("Content-Type: image/jpeg\r\n");
        res.write("Content-Length: " + data.length + "\r\n");
        res.write("\r\n");
        res.write(data, 'binary');
        res.write("\r\n");
    };

    send_next(fs.readFileSync(IMG));

    const updateImgInterval = setInterval(function () {
        if (stop) clearInterval(updateImgInterval);

        rsmq.receiveMessageAsync({qname: QUE, vt: 0})
            .then(function (resp) {
                if (resp.id) {
                    send_next(Buffer.from(resp.message, 'base64'))
                } else {
                    console.log("[RSMQ] FACE - No messages for me...")
                }
            })
            .catch(function (err) {
                console.error(`[RSMQ] FACEIMG - [ERROR] RECEIVE queue ${QUE} failed:, ${err.message}`)
            });
    }, 100);

    res.connection.on('close', function () {
        stop = true;
    });
});

*/

module.exports = router;
