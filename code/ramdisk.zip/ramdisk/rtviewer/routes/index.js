const fs = require('fs');
var exec = require('child_process').exec;

var express = require('express');
var router = express.Router();


const FACE_MJPEG = __dirname + "/../" + 'public/resource/face.jpg';
const SMPL_ORIG = __dirname + "/../" + "public/resource/original.jpg";
const SMPL_RENDER = __dirname + "/../" + "public/resource/rendered.jpg";


const now = function(){ return Math.floor( new Date().getTime()/1000 );};


/* GET home page. */
router.get('/', function(req, res, next) {
  res.sendfile('public/viewply.html');
  // res.sendfile('public/webgl_loader_ply.html')
});

router.get('/3d', function(req, res, next) {
  res.sendfile('public/css3d_panorama.html');
});

router.get('/smpl', function(req, res, next) {
  res.sendfile('public/smpl2.html');
});


router.get('/2_0.ply', function (req, res, netxt) {
  res.sendfile('public/resource/2_0.ply');
});

router.get('/api/face.json', function (req, res, netxt) {
  res.sendfile('public/resource/face.json');
});


router.get('/face.mjpg', function (req, res, netxt) {
    const IMG = FACE_MJPEG;
    res.writeHead(200, {
        'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
        'Cache-Control': 'no-cache',
        'Connection': 'close',
        'Pragma': 'no-cache'
    });

    var stop = false;
    var mtime = 0;
    const updateImgInterval = setInterval(function () {

        var st = fs.statSync(IMG);
        if (st && 'mtimeMs' in st && st.mtimeMs - mtime > 0) {
            send_next()
            mtime = st.mtimeMs;
        }

    }, 100);

    res.connection.on('close', function() { stop = true; });

    const send_next = function() {

        if (stop) return;

        fs.readFile(IMG, function (err, content) {
            res.write("--myboundary\r\n");
            res.write("Content-Type: image/jpeg\r\n");
            res.write("Content-Length: " + content.length + "\r\n");
            res.write("\r\n");
            res.write(content, 'binary');
            res.write("\r\n");

        });
    };
    send_next();

});

router.get('/face.mjpg1', function (req, res, netxt) {
  const IMG = FACE_MJPEG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {

      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }
  });

  var i = 0;
  const update = setInterval(function () {
    i = (i+1);
    if (stop) {
      clearInterval(update);
      watcher.close();
      res.end();
    }
    var ii = (i) % 100;
    // var filename =  __dirname + '/../public/resource/img/' +  ii + ".jpg";
    var filename = __dirname + '/../public/resource/selfie3f.jpg';


    var txt = fs.readFileSync ( filename,  'binary');

    fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})
    /*
    cmd = "cp -rf " + filename + " " + IMG;
    exec(cmd, function(err, stdout, stderr) {
      if (err) {
        console.log(err)
      }
    });*/

  }, 1000);

  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


router.get('/smpl_orig.mjpg', function (req, res, netxt) {

  const IMG = SMPL_ORIG;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {
      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }

  });

/*
  var i = 0;
  const update = setInterval(function () {
    i = (i+1);
    if (i > 100 || stop) {
      clearInterval(update);
      watcher.close();
      res.end();
    }
    var ii = (i) % 100;
    var filename =  __dirname + '/../public/resource/original11.jpg';

    var txt = fs.readFileSync ( filename,  'binary');

    fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})


  }, 1000);*/


  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


router.get('/smpl_render.mjpg', function (req, res, netxt) {

  const IMG = SMPL_RENDER;
  res.writeHead(200, {
    'Content-Type': 'multipart/x-mixed-replace; boundary=myboundary',
    'Cache-Control': 'no-cache',
    'Connection': 'close',
    'Pragma': 'no-cache'
  });

  var stop = false;

  const watcher = fs.watch(IMG, (eventType, filename) => {

    if (stop) {
      watcher.close();
      res.end();
    } else {
      try {
        var st = fs.statSync(IMG);
        if (st && 'size' in st && st.size > 0) {

          console.log(`event type is: ${eventType}, filename: ${filename}, size: ${st.size} @${now()}`);
          send_next()
        }
      } catch (e) {
        console.log(IMG, "stat error", e)
      }

    }

  });

  /*
    var i = 0;
    const update = setInterval(function () {
      i = (i+1);
      if (i > 100 || stop) {
        clearInterval(update);
        watcher.close();
        res.end();
      }
      var ii = (i) % 100;
      var filename =  __dirname + '/../public/resource/img/' +  ii + ".jpg";
      console.log(1111, filename);

      var txt = fs.readFileSync ( filename,  'binary');

      fs.writeFileSync(IMG, txt,{encoding:'binary',flag:'w'})


    }, 200);
    */

  res.connection.on('close', function() { stop = true; });

  const send_next = function() {

    if (stop) return;

    fs.readFile(IMG, function (err, content) {
      res.write("--myboundary\r\n");
      res.write("Content-Type: image/jpeg\r\n");
      res.write("Content-Length: " + content.length + "\r\n");
      res.write("\r\n");
      res.write(content, 'binary');
      res.write("\r\n");

    });
  };
  send_next();

});


module.exports = router;
